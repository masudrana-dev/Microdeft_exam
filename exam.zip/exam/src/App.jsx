import "./App.css";
import Registration from "./Components/Register/Registration";

function App() {
  return <Registration />;
}

export default App;
