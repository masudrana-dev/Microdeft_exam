import { useState } from "react";

const Registration = () => {
  const [name, setName] = useState(" ");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailErr, setEmailErr] = useState("");
  const [nameErr, setErr] = useState("");
  const [passwordErr, setPasswordErr] = useState("");

  const handleFirstname = (e) => {
    setName(e.target.value);
  };
  const handleEmail = (e) => {
    setEmail(e.target.value);
  };
  const handlePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name) {
      setErr("plz enter your name");
    }
    if (!email) {
      setEmailErr("plz enter your eamil");
    }
    if (!password) {
      setPasswordErr("plz enter password");
    }
  };
  return (
    <div className="border border-sky-500 w-[500px] h-[500px] m-auto rounded-lg">
      <div className="mt-20">
        <h1 className="font-bold text-[30px]">Register</h1>
        <form action="" className=" m-auto">
          <input
            className="border border-blue-400 w-[300px] h-[50px] mr-8 mb-4"
            type="text"
            placeholder="Name"
            onChange={handleFirstname}
          />
          {nameErr}
          <br />
          <input
            className="border border-blue-400 w-[300px] h-[50px] mr-8 mb-4"
            type="email"
            placeholder="email"
            onChange={handleEmail}
          />
          <p>{emailErr} </p>
          <br />
          <input
            className="border border-blue-400 w-[300px] h-[50px] mr-8 mb-4"
            type="password"
            placeholder="Password"
            onChange={handlePassword}
          />
          <p>{passwordErr} </p>
          <br />
          <button
            className="border border-orange-500 bg-orange-500 px-10 py-4 rounded-lg"
            onClick={handleSubmit}
          >
            submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default Registration;
